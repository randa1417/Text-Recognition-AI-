import cv2
import numpy as np


def Get_Contoure(img, cthr=[100, 100], show_canny=False, min_Area=1000, filter=0, draw=False):
    img_Gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img_Blur = cv2.GaussianBlur(img_Gray, (5, 5), 1)
    img_Canny = cv2.Canny(img_Blur, cthr[0], cthr[1])
    kernal = np.ones( (5,5) , )
    img_Dilation = cv2.dilate(img_Canny, kernal, iterations=3)
    img_Erod = cv2.erode(img_Dilation, kernal, iterations=3)

    if show_canny == True:
        cv2.imshow('Canny', img_Erod)
    contour , hiearch = cv2.findContours(img_Erod, cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    final_contour = []
    for i in contour:
        Area = cv2.contourArea(i)
        if Area > min_Area:
            prameter = cv2.arcLength(i, True)
            approx = cv2.approxPolyDP(i, 0.02*prameter, True)
            boun_box = cv2.boundingRect(approx)

            if filter > 0 :
                if len(approx) == filter:
                    final_contour.append([len(approx), Area, approx, boun_box, i])
            else:
                final_contour.append( [len(approx), Area, approx, boun_box, i] )
    final_contour = sorted(final_contour, key=lambda x:x[1], reverse=True)
    if draw == True:
        for con in final_contour:
            cv2.drawContours(img, con[4], -1, (0, 0, 255), 3)


    return img, final_contour

def re_order(my_point):
    print(my_point.shape)
    my_point_New = np.zeros_like(my_point)
    my_point = my_point.reshape((4,2))
    add = my_point.sum(1)
    my_point_New[0] = my_point[np.argmin(add)]
    my_point_New[3] = my_point[np.argmax(add)]
    diff = np.diff(my_point,axis=1)
    my_point_New[1] = my_point[np.argmin(diff)]
    my_point_New[2] = my_point[np.argmax(diff)]

    return my_point_New

def warp_img(img ,point ,w ,h , pad=20):
    # print(point)
    point = re_order(point)

    pts1 = np.float32(point)
    pts2 = np.float32([ [0,0] , [w,0] , [0,h] , [w,h] ])
    mat = cv2.getPerspectiveTransform(pts1,pts2)
    img_warp = cv2.warpPerspective(img,mat,(w,h))
    img_warp = img_warp[pad:img_warp.shape[0]-pad , pad:img_warp.shape[1]-pad]


    return img_warp


def find_Distance(pts1,pts2):
    a = (pts2[0]-pts1[0])**2
    b = (pts2[1]-pts1[1])**2
    c = (a + b)**0.5  # c = a*2 +b*2  فرق بين مربعين
    return c