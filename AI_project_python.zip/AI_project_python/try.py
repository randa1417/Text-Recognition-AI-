import cv2
import functions
import numpy as np

webcam = False
path = 'r5.png'

cap = cv2.VideoCapture(0)
cap.set(10,160)
cap.set(3,1920)
cap.set(4,1080)
scale = 2
W_paper = 270*scale
H_paper = 370*scale

read_vid = cv2.VideoCapture(0,cv2.CAP_DSHOW)
if (read_vid.isOpened() == False):
    print("Error for read video")

while (read_vid.isOpened()):
    ret, frame = read_vid.read()

    if ret == True:
        cv2.imshow('frame', frame)
        #img = cv2.imread(path)
        imgcon, final_contour = functions.Get_Contoure(frame,min_Area=50000, filter=4)


        if len(final_contour) != 0:
            big_contor = final_contour[0][2] # the first index will be the biggest becuse I sorted Descending order
            img_warp = functions.warp_img(frame, big_contor, W_paper , H_paper)

            imgcon2, final_contour2 = functions.Get_Contoure(img_warp, cthr=[50,50],draw=False, min_Area=2000, filter=4)
            if len(final_contour) != 0 :
                for obj in final_contour2:
                    cv2.polylines(imgcon2, [ obj[2] ], True, (0, 255, 0), 2)
                    num_point = functions.re_order(obj[2])

                    Dis_W = (functions.find_Distance(num_point[0][0]//scale,num_point[1][0]//scale)/10)
                    Dis_H = (functions.find_Distance(num_point[0][0]//scale,num_point[2][0]//scale)/10)

                    New_W = round(Dis_W,1)
                    New_H = round(Dis_H, 1)
                    cv2.arrowedLine(imgcon2, (num_point[0][0][0], num_point[0][0][1]),
                                    (num_point[1][0][0], num_point[1][0][1]),
                                    (255, 0, 255), 3, 8, 0, 0.05)
                    cv2.arrowedLine(imgcon2, (num_point[0][0][0], num_point[0][0][1]),
                                    (num_point[2][0][0], num_point[2][0][1]),
                                    (255, 0, 255), 3, 8, 0, 0.05)
                    x, y, w, h = obj[3]
                    cv2.putText(imgcon2, '{}cm'.format(New_W), (x + 30, y - 10), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1.5,
                                (255, 0, 255), 2)
                    cv2.putText(imgcon2, '{}cm'.format(New_H), (x - 70, y + h // 2), cv2.FONT_HERSHEY_COMPLEX_SMALL,
                                1.5,
                                (255, 0, 255), 2)

            cv2.imshow('Warp Image', imgcon2)

        cv2.imshow('Orignal', frame)
        cv2.waitKey(0)
        if cv2.waitKey(90) == ord('q'):
            break

    else:
        cv2.waitKey(0)

read_vid.release()
cv2.destroyAllWindows()
