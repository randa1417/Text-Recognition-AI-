import cv2
import pytesseract

pytesseract.pytesseract.tesseract_cmd = 'C:\\Program Files\\Tesseract_ocr\\tesseract.exe'

img = cv2.imread('pic2.png')
# img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
# width , height = 1000 , 500

# img_resize = cv2.resize(img,(width,height))
# H_img , W_img, _ = img_resize.shape
text = pytesseract.image_to_string(img)
#boxes = pytesseract.image_to_boxes(img_resize)
# cong = r'--oem 3 --psm 6 outputbase digits'
# boxes2 = pytesseract.image_to_data(img_resize,config=cong)
print(text)
#print(boxes2)
#
# for x,box in enumerate(boxes2.splitlines()):
#     if x!= 0 : #0 is heading row
#         box = box.split()
#         print(box) #print all boxes
#         if len(box) == 12 and len(box[11]) == 10:  # index 12 is the text & len(box[11]) is length of number
#             print(box)
#             num_ID = box[11]
#
# print("\nFinal Result")
# print(num_ID)

# cv2.imshow('image',img_resize)
# cv2.waitKey(0)