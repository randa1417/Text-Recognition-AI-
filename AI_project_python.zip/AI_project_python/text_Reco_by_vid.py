'''

    - Take a live video by camera ( many Frames )
    - Make some filtering for the video to be more clear like --> opening , Erosion ....
    - Read just a Digit from single frame that have a '10 number' such as --> 1092343423 & print it

'''


import cv2
import numpy as np
import pytesseract

pytesseract.pytesseract.tesseract_cmd = 'C:\\Program Files\\Tesseract_ocr\\tesseract.exe'

read_vid = cv2.VideoCapture(0,cv2.CAP_DSHOW)
if (read_vid.isOpened() == False):
    print("Error for read video")

while (read_vid.isOpened()):
    ret, frame = read_vid.read()

    if ret == True:
        cv2.imshow('frame', frame)
        # img = cv2.fastNlMeansDenoisingColored(frame, None, 10, 10, 7, 21)
        kerna_matrix = np.ones((2, 2), np.uint8)
        # img = cv2.erode(img, kerna_matrix, iterations=0)
        img = cv2.morphologyEx(frame, cv2.MORPH_OPEN, kerna_matrix) # opining to be more clear
        cong = r'--oem 3 --psm 6 outputbase digits'
        boxes2 = pytesseract.image_to_data(frame, config=cong)
        num_ID = 0
        for x, box in enumerate(boxes2.splitlines()):
            if x != 0:  # 0 is heading row
                box = box.split()
                #print(box)  # print all boxes
                if len(box) == 12 and len(box[11]) == 10:  # index 12 is the text & len(box[11]) is length of number
                    # print(box)
                    num_ID = box[11]

        print("\nFinal Result")
        print(num_ID)

        if cv2.waitKey(90) == ord('q'):
            break
    else:
            cv2.waitKey(0)

read_vid.release()
cv2.destroyAllWindows()